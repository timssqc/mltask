import string
import sys
import cPickle
import numpy as np


def print_dict(dict_obj,info):
    print info
    for k,v in dict_obj.iteritems():
        print k,v


def raw2dict(reload_model = None, train_data="CR-MR.train", test_data = "CR-MR.test", path = "MR-CR.pkl",path_of_emb = "../data/glove.6B.50d.txt.deal"):
    dict_emb={}
    dict_word={}
    dict_id2word={}

    dict_task={}
    dict_id2task={}


    dict_label_list=[]
    dict_id2label_list=[]

    train_label_set_list = []
    train_sen_set_list = []
    train_sup_set_list = []


    dict_word["<padding>"] = 0
    dict_id2word[0] = "<padding>"

    dict_word["<unk>"] = 1
    dict_id2word[1] = "<unk>"

    if reload_model:
        f = open(path, 'rb')
        _ = cPickle.load(f)
        _ = cPickle.load(f)
        _ = cPickle.load(f)
        dict_id2task = cPickle.load(f)
        dict_word = cPickle.load(f)
        dict_id2word = cPickle.load(f)
        print "load dict size:",len(dict_word)
        f.close()


    fin = open(train_data,"r")

    for line in fin:
        line = line.rstrip("\n")
        triplet = line.split("\t")
        if len(triplet) != 4:
            continue
        task_type = triplet[0]
        label = triplet[1]
        sen   = triplet[2]
        sup   = string.atoi(triplet[3])
        sen =sen.replace("-"," ").replace("/"," ").replace("\'","").replace("."," ")
        sen = " ".join(sen.split())
        if len(sen.split(" ")) > 350:
            continue

        if dict_task.has_key(task_type) == False:
            length = len(dict_task)
            dict_task[task_type] = length
            dict_id2task[length] = task_type

            dict_label={}
            dict_id2label={}
            dict_label_list.append(dict_label)
            dict_id2label_list.append(dict_id2label)
            train_label_set_list.append([])
            train_sup_set_list.append([])
            train_sen_set_list.append([])
        if dict_label_list[dict_task[task_type]].has_key(label) == False:
            length1 = len(dict_label_list[dict_task[task_type]])
            dict_label_list[dict_task[task_type]][label] = length1
            dict_id2label_list[dict_task[task_type]][length1] = label


        train_label_set_list[dict_task[task_type]].append(dict_label_list[dict_task[task_type]][label]);
        train_sup_set_list[dict_task[task_type]].append(sup);

        sen_list = []
        for w in sen.split(" "):
            if dict_word.has_key(w) == False:
                if reload_model:
                    print "reload find no"
                    sen_list.append(1)
                else:
                    length = len(dict_word)
                    dict_word[w] = length
                    dict_id2word[length] = w
                    sen_list.append(dict_word[w])
            else:
                sen_list.append(dict_word[w])
        train_sen_set_list[dict_task[task_type]].append(sen_list)


    fin.close()
    task_num = len(dict_task)





    #test_data = "CR-MR.test"
    test_label_set_list=[]
    test_sen_set_list=[]
    test_sup_set_list=[]
    for i in range(task_num):
        test_label_set_list.append([])
        test_sup_set_list.append([])
        test_sen_set_list.append([])

    fin = open(test_data,"r")
    for line in fin:
        line = line.rstrip("\n")
        triplet = line.split("\t")
        if len(triplet) != 4:
            continue
        task_name = triplet[0]
        label = triplet[1]
        sen   = triplet[2]
        sup   = string.atoi(triplet[3])
        sen =sen.replace("-"," ").replace("/"," ").replace("\'","").replace("."," ")
        sen = " ".join(sen.split())
        if len(sen.split(" ")) > 350:
            continue

        task_type = dict_task[task_name]

        test_label_set_list[task_type].append(dict_label_list[task_type][label])
        test_sup_set_list[task_type].append(sup)

        sen_list = []
        for w in sen.split(" "):
            if dict_word.has_key(w) == False:
                if reload_model:
                    sen_list.append(1)
                    print "reload find no"
                else:
                    length = len(dict_word)
                    dict_word[w] = length
                    dict_id2word[length] = w
                    sen_list.append(dict_word[w])
            else:
                sen_list.append(dict_word[w])
        test_sen_set_list[task_type].append(sen_list)
    fin.close()

    train_pair = (train_sen_set_list, train_label_set_list, train_sup_set_list)
    test_pair = (test_sen_set_list, test_label_set_list, test_sup_set_list)
    #---------------------------------------------------------------------#
    w_dim=0
    fin = open(path_of_emb,"r")
    for line in fin:
        line = line.rstrip("\n")
        pair = line.split("\t")
        word = pair[0]
        dict_emb[word] = pair[1]
        if w_dim == 0:
            w_dim = len(pair[1].split(" "))
    fin.close()

    oov = 0
    vocab_size = len(dict_word)

    w_emb = 0.01 * np.random.rand(vocab_size,w_dim)
    for i in range(vocab_size):
        word = dict_id2word[i]
        if dict_emb.has_key(word):
            emb_list = dict_emb[word]
            w_emb[i,:] = np.array([string.atof(e) for e in emb_list.split(" ")])

        else:
            #print word
            oov += 1

    print "OOV of Dataset is:\t" + str(oov*1.0/vocab_size)
    print "len(dict):\t", vocab_size
    #Save Model
    fout = file(path,"wb")
    cPickle.dump(train_pair,fout,protocol=cPickle.HIGHEST_PROTOCOL)
    cPickle.dump(test_pair,fout,protocol=cPickle.HIGHEST_PROTOCOL)
    cPickle.dump(w_emb,fout,protocol=cPickle.HIGHEST_PROTOCOL)

    cPickle.dump(dict_id2task,fout,protocol=cPickle.HIGHEST_PROTOCOL)
    cPickle.dump(dict_word,fout,protocol=cPickle.HIGHEST_PROTOCOL)
    cPickle.dump(dict_id2word,fout,protocol=cPickle.HIGHEST_PROTOCOL)
    fout.close()
