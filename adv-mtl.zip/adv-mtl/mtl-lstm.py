from collections import OrderedDict
import cPickle as pkl
import sys
import time

import numpy
import theano
from theano import config
import theano.tensor as tensor
from theano.sandbox.rng_mrg import MRG_RandomStreams as RandomStreams
import string
import data

datasets = {'data': (data.load_data, data.prepare_data)}

# Set the random number generators' seeds for consistency
SEED = 123
numpy.random.seed(SEED)

def numpy_floatX(data):
    return numpy.asarray(data, dtype=config.floatX)


def get_minibatches_idx(n, minibatch_size, task_type, shuffle=False):
    """
    Used to shuffle the dataset at each iteration.
    """

    idx_list = numpy.arange(n, dtype="int32")

    if shuffle:
        numpy.random.shuffle(idx_list)

    minibatches = []
    minibatch_start = 0
    for i in range(n // minibatch_size):
        minibatches.append(idx_list[minibatch_start:
                                    minibatch_start + minibatch_size])
        minibatch_start += minibatch_size

    if (minibatch_start != n):
        # Make a minibatch out of what is left
        minibatches.append(idx_list[minibatch_start:])

    #return zip(range(len(minibatches)), minibatches)
    return zip([task_type for i in range(len(minibatches))], minibatches)


def get_dataset(name):
    return datasets[name][0], datasets[name][1]

def concatenate(tensor_list, axis=0):
    """
    Alternative implementation of `theano.tensor.concatenate`.
    This function does exactly the same thing, but contrary to Theano's own
    implementation, the gradient is implemented on the GPU.
    Backpropagating through `theano.tensor.concatenate` yields slowdowns
    because the inverse operation (splitting) needs to be done on the CPU.
    This implementation does not have that problem.
    :usage:
        >>> x, y = theano.tensor.matrices('x', 'y')
        >>> c = concatenate([x, y], axis=1)
    :parameters:
        - tensor_list : list
            list of Theano tensor expressions that should be concatenated.
        - axis : int
            the tensors will be joined along this axis.
    :returns:
        - out : tensor
            the concatenated tensor expression.
    """
    concat_size = sum(tt.shape[axis] for tt in tensor_list)

    output_shape = ()
    for k in range(axis):
        output_shape += (tensor_list[0].shape[k],)
    output_shape += (concat_size,)
    for k in range(axis + 1, tensor_list[0].ndim):
        output_shape += (tensor_list[0].shape[k],)

    out = tensor.zeros(output_shape)
    offset = 0
    for tt in tensor_list:
        indices = ()
        for k in range(axis):
            indices += (slice(None),)
        indices += (slice(offset, offset + tt.shape[axis]),)
        for k in range(axis + 1, tensor_list[0].ndim):
            indices += (slice(None),)

        out = tensor.set_subtensor(out[indices], tt)
        offset += tt.shape[axis]

    return out

def zipp(params, tparams):
    """
    When we reload the model. Needed for the GPU stuff.
    """
    for kk, vv in params.iteritems():
        tparams[kk].set_value(vv)


def unzip(zipped):
    """
    When we pickle the model. Needed for the GPU stuff.
    """
    new_params = OrderedDict()
    for kk, vv in zipped.iteritems():
        new_params[kk] = vv.get_value()
    return new_params


def dropout_layer(state_before, use_noise, trng):
    proj = tensor.switch(use_noise,
                         (state_before *
                          trng.binomial(state_before.shape,
                                        p=0.5, n=1,
                                        dtype=state_before.dtype)),
                         state_before * 0.5)
    return proj


def _p(pp, name):
    return '%s_%s' % (pp, name)


def norm_weight(nin,nout=None, scale=0.01, ortho=True):
    """
    Random weights drawn from a Gaussian
    """
    if nout is None:
        nout = nin
    if nout == nin and ortho:
        W = ortho_weight(nin)
    else:
        W = scale * numpy.random.randn(nin, nout)
    return W.astype('float32')

# some useful shorthands
def tanh(x):
    return tensor.tanh(x)

def rectifier(x):
    return tensor.maximum(0., x)

def linear(x):
    return x

# feedforward layer: affine transformation + point-wise nonlinearity
def param_init_fflayer(options, params, prefix='ff', nin=None, nout=None):
    if nin is None:
        nin = options['dim_proj']
    if nout is None:
        nout = options['dim_proj']
    params[_p(prefix, 'W')] = norm_weight(nin, nout, scale=0.01)
    params[_p(prefix, 'b')] = numpy.zeros((nout,)).astype('float32')
    return params

def fflayer(tparams, state_below, options, prefix='rconv', activ='lambda x: tensor.tanh(x)', **kwargs):
    return eval(activ)(tensor.dot(state_below, tparams[_p(prefix,'W')])+tparams[_p(prefix,'b')])









def init_params(options,num_task):
    """
    Global (not LSTM) parameter. For the embeding and the classifier.
    """
    # embedding
    randn = 0.01 * numpy.random.rand(options['n_words'],
                              options['dim_proj'])
    #params['Wemb'] = (0.01 * randn).astype(config.floatX)
    if options['flag_initEmb'] == 1:
        randn = options['w_emb']

    '''
    Put your shared weight here !!!
    '''

    prefix=options['encoder']
    params_shared = OrderedDict()
    params_shared_D = OrderedDict()
    params_shared['Wemb'] = (randn).astype(config.floatX)


    W = numpy.concatenate([ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj'])], axis=1)
    params_shared[_p(prefix, 'W')] = W

    U = numpy.concatenate([ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj'])], axis=1)
    params_shared[_p(prefix, 'U')] = U

    b = numpy.zeros((4 * options['dim_proj'],))
    params_shared[_p(prefix, 'b')] = b.astype(config.floatX)



    params_shared_D['U_s'] = 0.01 * numpy.random.randn(options['dim_proj'],
                                        options['num_task']).astype(config.floatX)
    params_shared_D['b_s'] = numpy.zeros((options['num_task'],)).astype(config.floatX)


    params_list = []
    params_D_list = []
    for task in range(num_task):
        params = OrderedDict()
        params_D = OrderedDict()

        #params['Wemb'] = (randn).astype(config.floatX)
        params = get_layer(options['encoder_task'])[0](options,
                                                  params,
                                                  prefix=options['encoder_task'])


        
        # classifier
        params_D['U'] = 0.01 * numpy.random.randn(options['dim_proj'],
                                                options['ydim_list'][task]).astype(config.floatX)
        params_D['b'] = numpy.zeros((options['ydim_list'][task],)).astype(config.floatX)

        params_D = get_layer('ff')[0](options, params_D, prefix='ff_state', nin = 1 * options['dim_proj'], nout = options['dim_proj'])

        params_D_list.append(params_D);
        params_list.append(params);
    return params_list, params_shared, params_shared_D, params_D_list


def load_params(path, params_list, params_shared, params_shared_D, params_D_list, num_task):
    for task in range(num_task+2):
        #print "new_path: ", new_path
        if task == num_task+1:
            new_path = path + "_" + str(2*num_task+1) + ".npz"
            pp = numpy.load(new_path)
            for kk, vv in params_shared_D.iteritems():
                if kk not in pp:
                    raise Warning('%s is not in the archive' % kk)
                params_shared_D[kk] = pp[kk]
        elif task == num_task:
            new_path = path + "_" + str(2*num_task) + ".npz"
            pp = numpy.load(new_path)
            for kk, vv in params_shared.iteritems():
                if kk not in pp:
                    raise Warning('%s is not in the archive' % kk)
                params_shared[kk] = pp[kk]
        else:
            new_path = path + "_" + str(2*task) + ".npz"
            pp = numpy.load(new_path)
            for kk, vv in params_list[task].iteritems():
                if kk not in pp:
                    raise Warning('%s is not in the archive' % kk)
                params_list[task][kk] = pp[kk]
            new_path = path + "_" + str(2*task+1) + ".npz"
            pp = numpy.load(new_path)
            for kk, vv in params_D_list[task].iteritems():
                if kk not in pp:
                    raise Warning('%s is not in the archive' % kk)
                params_D_list[task][kk] = pp[kk]

    return params_list, params_shared, params_shared_D, params_D_list


def init_tparams(params_list,params_shared, params_shared_D, params_D_list, num_task):

    tparams_shared_D = OrderedDict()
    for kk, pp in params_shared_D.iteritems():
        tparams_shared_D[kk] = theano.shared(params_shared_D[kk], name=kk)


    tparams_shared = OrderedDict()
    for kk, pp in params_shared.iteritems():
        tparams_shared[kk] = theano.shared(params_shared[kk], name=kk)

    tparams_list = []
    tparams_D_list = []
    for task in range(num_task):
        tparams = OrderedDict()
        for kk, pp in params_list[task].iteritems():
            tparams[kk] = theano.shared(params_list[task][kk], name=kk)
        tparams_list.append(tparams)

        tparams_D = OrderedDict()
        for kk, pp in params_D_list[task].iteritems():
            tparams_D[kk] = theano.shared(params_D_list[task][kk], name=kk)
        tparams_D_list.append(tparams_D)

    return tparams_list,tparams_shared,tparams_shared_D, tparams_D_list


def get_layer(name):
    fns = layers[name]
    return fns


def ortho_weight(ndim):
    W = numpy.random.randn(ndim, ndim)
    u, s, v = numpy.linalg.svd(W)
    return u.astype(config.floatX)


def param_init_lstm(options, params, prefix='lstm'):
    """
    Init the LSTM parameter:

    :see: init_params
    """
    W = numpy.concatenate([ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj'])], axis=1)
    params[_p(prefix, 'W')] = W
    U = numpy.concatenate([ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj']),
                           ortho_weight(options['dim_proj'])], axis=1)
    params[_p(prefix, 'U')] = U
    b = numpy.zeros((4 * options['dim_proj'],))
    params[_p(prefix, 'b')] = b.astype(config.floatX)

    return params


def lstm_layer(tparams, state_below, options, prefix='lstm', mask=None):
    nsteps = state_below.shape[0]
    if state_below.ndim == 3:
        n_samples = state_below.shape[1]
    else:
        n_samples = 1

    assert mask is not None

    def _slice(_x, n, dim):
        if _x.ndim == 3:
            return _x[:, :, n * dim:(n + 1) * dim]
        return _x[:, n * dim:(n + 1) * dim]

    def _step(m_, x_, h_, c_):
        preact = tensor.dot(h_, tparams[_p(prefix, 'U')])
        preact += x_

        i = tensor.nnet.sigmoid(_slice(preact, 0, options['dim_proj']))
        f = tensor.nnet.sigmoid(_slice(preact, 1, options['dim_proj']))
        o = tensor.nnet.sigmoid(_slice(preact, 2, options['dim_proj']))
        c = tensor.tanh(_slice(preact, 3, options['dim_proj']))

        c = f * c_ + i * c
        c = m_[:, None] * c + (1. - m_)[:, None] * c_

        h = o * tensor.tanh(c)
        h = m_[:, None] * h + (1. - m_)[:, None] * h_

        return h, c

    state_below = (tensor.dot(state_below, tparams[_p(prefix, 'W')]) +
                   tparams[_p(prefix, 'b')])

    dim_proj = options['dim_proj']
    rval, updates = theano.scan(_step,
                                sequences=[mask, state_below],
                                outputs_info=[tensor.alloc(numpy_floatX(0.),
                                                           n_samples,
                                                           dim_proj),
                                              tensor.alloc(numpy_floatX(0.),
                                                           n_samples,
                                                           dim_proj)],
                                name=_p(prefix, '_layers'),
                                n_steps=nsteps)
    return rval[0]






















# ff: Feed Forward (normal neural net), only useful to put after lstm
#     before the classifier.
layers = {'lstm': (param_init_lstm, lstm_layer),
          'lstm_task': (param_init_lstm, lstm_layer),
          'ff': (param_init_fflayer, fflayer),
    }




def sgd(lr, tparams, grads, x, mask, y, cost):
    """ Stochastic Gradient Descent

    :note: A more complicated version of sgd then needed.  This is
        done like that for adadelta and rmsprop.

    """
    # New set of shared variable that will contain the gradient
    # for a mini-batch.
    gshared = [theano.shared(p.get_value() * 0., name='%s_grad' % k)
               for k, p in tparams.iteritems()]
    gsup = [(gs, g) for gs, g in zip(gshared, grads)]

    # Function that computes gradients for a mini-batch, but do not
    # updates the weights.
    f_grad_shared = theano.function([x, mask, y], cost, updates=gsup,
                                    name='sgd_f_grad_shared')

    pup = [(p, p - lr * g) for p, g in zip(tparams.values(), gshared)]

    # Function that updates the weights from the previously computed
    # gradient.
    f_update = theano.function([lr], [], updates=pup,
                               name='sgd_f_update')

    return f_grad_shared, f_update


def adadelta(options, lr, tparams, tparams_shared, tparams_shared_D, tparams_D, grads, x, mask, y, y_s, cost, grads_s, cost_s, mask_sup, grads_diff, cost_diff):
    """
    An adaptive learning rate optimizer

    Parameters
    ----------
    lr : Theano SharedVariable
        Initial learning rate
    tpramas: Theano SharedVariable
        Model parameters
    grads: Theano variable
        Gradients of cost w.r.t to parameres
    x: Theano variable
        Model inputs
    mask: Theano variable
        Sequence mask
    y: Theano variable
        Targets
    cost: Theano variable
        Objective fucntion to minimize

    Notes
    -----
    For more information, see [ADADELTA]_.

    .. [ADADELTA] Matthew D. Zeiler, *ADADELTA: An Adaptive Learning
       Rate Method*, arXiv:1212.5701.
    """

    #-------------------G Loss on shared LSTM except 'Emb'-----------------------
    '''
    grads[]:    tparams + tparams_D + tparams_shared
    grads_s[]:                        tparams_shared + tparams_shared_D
    '''
    len_task = len(tparams.keys()+tparams_D.keys())
    for i in range(len(tparams_shared.keys())):
        if tparams_shared.keys()[i] == "Wemb" or options['eidx'] > options['G_stop']:
            continue
        grads[i+len_task] -= options['lambda_k'] * grads_s[i]

    #-------------------D Loss on MLP-----------------------
    len_G = len(tparams_shared.keys())
    for i in range(len(tparams_shared_D.keys())):
        grads.append(options['lambda_k'] * grads_s[i+len_G])

    '''
    grads[]:    tparams + tparams_D + tparams_shared + tparams_shared_D
    grads[]:    tparams +           + tparams_shared
    '''

    #-------------------diff Loss towards only task-specific lstm layer-----------------------
    for i in range(len(tparams.keys())):
        grads[i] += grads_diff[i]

    #tparams_merge = dict(tparams.items() + tparams_D.items())


    zipped_grads = [theano.shared(p.get_value() * numpy_floatX(0.),
                                  name='%s_grad' % k)
                    for k, p in tparams.iteritems()]
    zipped_grads += [theano.shared(p.get_value() * numpy_floatX(0.),
                                  name='%s_grad' % k)
                    for k, p in tparams_D.iteritems()]
    zipped_grads += [theano.shared(p.get_value() * numpy_floatX(0.),
                                  name='%s_grad' % k)
                    for k, p in tparams_shared.iteritems()]
    zipped_grads += [theano.shared(p.get_value() * numpy_floatX(0.),
                                  name='%s_grad' % k)
                    for k, p in tparams_shared_D.iteritems()]


    running_up2 = [theano.shared(p.get_value() * numpy_floatX(0.),
                                 name='%s_rup2' % k)
                   for k, p in tparams.iteritems()]
    running_up2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                 name='%s_rup2' % k)
                   for k, p in tparams_D.iteritems()]

    running_up2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                 name='%s_rup2' % k)
                   for k, p in tparams_shared.iteritems()]
    running_up2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                 name='%s_rup2' % k)
                   for k, p in tparams_shared_D.iteritems()]


    running_grads2 = [theano.shared(p.get_value() * numpy_floatX(0.),
                                    name='%s_rgrad2' % k)
                      for k, p in tparams.iteritems()]
    running_grads2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                    name='%s_rgrad2' % k)
                      for k, p in tparams_D.iteritems()]

    running_grads2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                    name='%s_rgrad2' % k)
                      for k, p in tparams_shared.iteritems()]
    running_grads2 += [theano.shared(p.get_value() * numpy_floatX(0.),
                                    name='%s_rgrad2' % k)
                      for k, p in tparams_shared_D.iteritems()]

    zgup = [(zg, g) for zg, g in zip(zipped_grads, grads)]
    rg2up = [(rg2, 0.95 * rg2 + 0.05 * (g ** 2))
             for rg2, g in zip(running_grads2, grads)]

    f_grad_shared = theano.function([x, mask, y, y_s, mask_sup], cost, updates=zgup + rg2up,
                                    name='adadelta_f_grad_shared')


    f_grad_shared_s = theano.function([x, mask, y_s], cost_s,
                                    name='adadelta_f_grad_shared_s')

    updir = [-tensor.sqrt(ru2 + 1e-6) / tensor.sqrt(rg2 + 1e-6) * zg
             for zg, ru2, rg2 in zip(zipped_grads,
                                     running_up2,
                                     running_grads2)]
    ru2up = [(ru2, 0.95 * ru2 + 0.05 * (ud ** 2))
             for ru2, ud in zip(running_up2, updir)]
    param_up = [(p, p + ud) for p, ud in zip(tparams.values()+ tparams_D.values() + tparams_shared.values()+tparams_shared_D.values(), updir)]

    f_update = theano.function([lr], [], updates=ru2up + param_up,
                               on_unused_input='ignore',
                               name='adadelta_f_update')

    return f_grad_shared, f_update,f_grad_shared_s


def rmsprop(lr, tparams, grads, x, mask, y, cost):
    """
    A variant of  SGD that scales the step size by running average of the
    recent step norms.

    Parameters
    ----------
    lr : Theano SharedVariable
        Initial learning rate
    tpramas: Theano SharedVariable
        Model parameters
    grads: Theano variable
        Gradients of cost w.r.t to parameres
    x: Theano variable
        Model inputs
    mask: Theano variable
        Sequence mask
    y: Theano variable
        Targets
    cost: Theano variable
        Objective fucntion to minimize

    Notes
    -----
    For more information, see [Hint2014]_.

    .. [Hint2014] Geoff Hinton, *Neural Networks for Machine Learning*,
       lecture 6a,
       http://cs.toronto.edu/~tijmen/csc321/slides/lecture_slides_lec6.pdf
    """

    zipped_grads = [theano.shared(p.get_value() * numpy_floatX(0.),
                                  name='%s_grad' % k)
                    for k, p in tparams.iteritems()]
    running_grads = [theano.shared(p.get_value() * numpy_floatX(0.),
                                   name='%s_rgrad' % k)
                     for k, p in tparams.iteritems()]
    running_grads2 = [theano.shared(p.get_value() * numpy_floatX(0.),
                                    name='%s_rgrad2' % k)
                      for k, p in tparams.iteritems()]

    zgup = [(zg, g) for zg, g in zip(zipped_grads, grads)]
    rgup = [(rg, 0.95 * rg + 0.05 * g) for rg, g in zip(running_grads, grads)]
    rg2up = [(rg2, 0.95 * rg2 + 0.05 * (g ** 2))
             for rg2, g in zip(running_grads2, grads)]

    f_grad_shared = theano.function([x, mask, y], cost,
                                    updates=zgup + rgup + rg2up,
                                    name='rmsprop_f_grad_shared')

    updir = [theano.shared(p.get_value() * numpy_floatX(0.),
                           name='%s_updir' % k)
             for k, p in tparams.iteritems()]
    updir_new = [(ud, 0.9 * ud - 1e-4 * zg / tensor.sqrt(rg2 - rg ** 2 + 1e-4))
                 for ud, zg, rg, rg2 in zip(updir, zipped_grads, running_grads,
                                            running_grads2)]
    param_up = [(p, p + udn[1])
                for p, udn in zip(tparams.values(), updir_new)]
    f_update = theano.function([lr], [], updates=updir_new + param_up,
                               on_unused_input='ignore',
                               name='rmsprop_f_update')

    return f_grad_shared, f_update


def build_model(tparams, tparams_shared, tparams_shared_D, tparams_D,options):
    trng = RandomStreams(SEED)

    # Used for dropout.
    use_noise = theano.shared(numpy_floatX(0.))

    x = tensor.matrix('x', dtype='int64')
    mask = tensor.matrix('mask', dtype=config.floatX)
    y = tensor.vector('y', dtype='int64')
    y_s = tensor.vector('y_s', dtype='int64')
    mask_sup = tensor.vector('mask_sup', dtype=config.floatX)

    n_timesteps = x.shape[0]
    n_samples = x.shape[1]

    emb = tparams_shared['Wemb'][x.flatten()].reshape([n_timesteps,
                                                n_samples,
                                                options['dim_proj']])

    # share lstm layer
    proj_s = get_layer(options['encoder'])[1](tparams_shared, emb, options,
                                            prefix=options['encoder'],
                                            mask=mask)

    proj = get_layer(options['encoder_task'])[1](tparams, emb, options,
                                            prefix=options['encoder_task'],
                                            mask=mask)


    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    off = 1e-8
    proj_s = (proj_s * mask[:, :, None])
    proj = (proj * mask[:, :, None])
    proj_s_plot = proj_s



    #----------------------------------------------------------------------------------------------------------
    # n * b * h --> b * n * h
    info = []
    info.append(proj_s.dimshuffle(1,0,2))


    proj_s = (proj_s * mask[:, :, None]).sum(axis=0)
    proj_s = proj_s / mask.sum(axis=0)[:, None]
    
    pred_s = tensor.nnet.softmax(tensor.dot(proj_s, tparams_shared_D['U_s']) + tparams_shared_D['b_s'])
    f_pred_prob_s = theano.function([x, mask], pred_s, name='f_pred_prob_s')
    f_pred_s = theano.function([x, mask], pred_s.argmax(axis=1), name='f_pred_s')

    cost_s = -tensor.log(pred_s[tensor.arange(n_samples), y_s] + off).mean()
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   

    #proj = (proj * mask[:, :, None])
    proj = get_layer('ff')[1](tparams_D, proj, options, prefix='ff_state', activ='tanh')
    proj = proj * mask[:, :, None]

    proj_plot = proj

    proj = (proj * mask[:, :, None]).sum(axis=0)
    proj = proj / mask.sum(axis=0)[:, None]
    #proj = proj * mask_sup[:, None]
    if options['use_dropout']:
        proj = dropout_layer(proj, use_noise, trng)



    pred = tensor.nnet.softmax(tensor.dot(proj+proj_s, tparams_D['U']) + tparams_D['b'])

    f_pred_prob = theano.function([x, mask], pred, name='f_pred_prob')
    f_pred = theano.function([x, mask], pred.argmax(axis=1), name='f_pred')





    #----------------------------------------------------------------------------------------------------------
    #info = []

    def _step(proj_slice,proj_s_):
        pred_plot_slice = tensor.nnet.softmax((tensor.dot(proj_slice+proj_s_, tparams_D['U']) + tparams_D['b'])) # n, b, 2
        return pred_plot_slice



    if options['n_samples_examine']:
        pred_plot, updates = theano.scan(_step,
                                    sequences=[proj_plot,proj_s_plot],
                                    outputs_info=[None])



        info += [pred_plot.argmax(axis=2), pred_plot.max(axis=2)]
    #----------------------------------------------------------------------------------------------------------

    if pred.dtype == 'float16':
        off = 1e-6


    #----------------------------  Diff ------------------------------------------------------------------------------
    def _step_dis(proj_, proj_s_):
        a = tensor.dot(proj_[:,None], proj_s_[None,:])
        res = tensor.sqrt((a ** 2).sum())
        return res

    cost_diff_list, updates = theano.scan(_step_dis,
                                sequences=[proj, proj_s],
                                outputs_info=[None])

    cost_diff = cost_diff_list.mean() * options['beta']
    info.append(cost_diff)


    #cost = -tensor.log(pred[tensor.arange(n_samples), y] + off).mean()
    ######## Unsupervised or Supervised Learning ####################
    cost = -tensor.log(pred[tensor.arange(n_samples), y] + off)
    cost = (cost * mask_sup).sum()/(mask_sup.sum()+off)

    f_info = theano.function([x, mask], info, name='f_info')

    #cost += cost_diff
    return use_noise, x, mask, y, f_pred_prob, f_pred, cost, y_s, cost_s, mask_sup,  f_pred_s, f_info, cost_diff


def pred_probs(f_pred_prob, prepare_data, data, iterator, verbose=False):
    """ If you want to use a trained model, this is useful to compute
    the probabilities of new examples.
    """
    n_samples = len(data[0])
    probs = numpy.zeros((n_samples, 2)).astype(config.floatX)

    n_done = 0

    for _, valid_index in iterator:
        x, mask, y, y_s, mask_sup= prepare_data([data[0][t] for t in valid_index],
                                  numpy.array(data[1])[valid_index], task_type, numpy.array(data[2])[valid_index],
                                  maxlen=None)
        pred_probs = f_pred_prob(x, mask)
        probs[valid_index, :] = pred_probs

        n_done += len(valid_index)
        if verbose:
            print '%d/%d samples classified' % (n_done, n_samples)

    return probs



def printMat(seq_word, mat_h):
    x,y = len(mat_h), len(mat_h[0])
    res = ""
    for i in range(x):
        if seq_word[i] == 0:
            break
        for j in range(y):
            if j == y-1:
                res += str(mat_h[i][j]) + "\n"
            else:
                res += str(mat_h[i][j]) + " "

    return res



def printJoint(options, dict_id2word, mat_word, target, predict, predict_plot, predict_prob_plot, hout_list):



    tot = 1
    n = len(mat_word)
    for i in range(n):
        m = len(mat_word[i])
        label = target[i]
        label_p = predict[i]

        flag = ""
        if label == label_p:
            flag = "right"
        else:
            flag = "false"

        if options['flag_badcase'] and flag == "right":
            continue


        mat_h = numpy.ndarray.tolist(hout_list[i])
        res_mat = printMat(mat_word[i], mat_h)

        sentence = flag + "\t" +"[glod: "+ str(label) + "]" + "\t" + "[predict: "+ str(label_p) + "]" + "\t"
        #sentence = flag + "\t" + str(label) +"[glod]"+ "\t" + str(label_p) +"[predict]" + "\t"
        sentence_info = "\t"

        #sys.stdout.write(str(predict[i])  +"\t")
        for j in range(m):
            w = dict_id2word[mat_word[i][j]]
            if w == '<padding>':
                break
            sentence += dict_id2word[mat_word[i][j]] + " "
            sentence_info += dict_id2word[mat_word[i][j]] + ":" + str(predict_plot[i][j]) + ":" + str(predict_prob_plot[i][j])+"\t"
        print sentence
        print sentence_info.rstrip("\t")
        print " "



        print res_mat

        tot += 1
        if tot > options['n_samples_examine']:
            break
    print '--------------------------------------------------------------------------------------'










def pred_error_detail(options, f_pred, f_info, prepare_data, data, iterator, task,verbose=False):
    """
    Just compute the error
    f_pred: Theano fct computing the prediction
    prepare_data: usual prepare_data for that dataset.
    """
    dict_id2word= options['dict_id2word']
    valid_err = 0

    x_list = []
    pred_list=[]
    target_list=[]
    pred_plot_list = []
    pred_prob_plot_list = []
    hout_list = []

    for task_type, valid_index in iterator:
        x, mask, y, y_s, mask_sup= prepare_data([data[0][task][t] for t in valid_index],
                                  numpy.array(data[1][task])[valid_index],task_type, numpy.array(data[2][task])[valid_index],
                                  maxlen=None)
        preds = f_pred(x, mask)
        targets = numpy.array(data[1][task])[valid_index]

        targets = targets * mask_sup + preds * (1-mask_sup)
        valid_err += (preds == targets).sum()

        # ----------- print infomation ----------------
        x_list += numpy.ndarray.tolist(x.T)
        pred_list += numpy.ndarray.tolist(preds)
        target_list += numpy.ndarray.tolist(targets)


        info = f_info(x,mask)
        pred_plot_list += numpy.ndarray.tolist(info[1].T)
        pred_prob_plot_list += numpy.ndarray.tolist(info[2].T)

        #hout_list += numpy.ndarray.tolist(info[0]) #b * n * h
        for i in range(len(info[0])):
            hout_list.append(info[0][i])

    #print "valid_er:\t%d" %(valid_err)
    delta = len(data[1][task]) - numpy.array(data[2][task]).sum()
    #print "delta:", delta, "len(data[2])",numpy.array(data[2][task]).sum(), "valid_err",valid_err
    valid_err = 1. - (numpy_floatX(valid_err)-delta) / numpy.array(data[2][task]).sum()


    printJoint(options, dict_id2word, x_list, target_list, pred_list, pred_plot_list, pred_prob_plot_list, hout_list)

    return valid_err







def pred_error(f_pred, prepare_data, data, iterator, task,verbose=False):
    """
    Just compute the error
    f_pred: Theano fct computing the prediction
    prepare_data: usual prepare_data for that dataset.
    """
    valid_err = 0
    for task_type, valid_index in iterator:
        x, mask, y, y_s, mask_sup= prepare_data([data[0][task][t] for t in valid_index],
                                  numpy.array(data[1][task])[valid_index],task_type, numpy.array(data[2][task])[valid_index],
                                  maxlen=None)
        preds = f_pred(x, mask)
        targets = numpy.array(data[1][task])[valid_index]

        targets = targets * mask_sup + preds * (1-mask_sup)
        #print "preds:"
        #print preds
        #print "targets:"
        #print targets
        valid_err += (preds == targets).sum()
    #print "valid_er:\t%d" %(valid_err)
    delta = len(data[1][task]) - numpy.array(data[2][task]).sum()
    #print "delta:", delta, "len(data[2])",numpy.array(data[2][task]).sum(), "valid_err",valid_err
    valid_err = 1. - (numpy_floatX(valid_err)-delta) / numpy.array(data[2][task]).sum()

    return valid_err



def pred_error_s(f_pred_s, prepare_data, data, iterator, task,verbose=False):
    """
    Just compute the error
    f_pred: Theano fct computing the prediction
    prepare_data: usual prepare_data for that dataset.
    """
    valid_err = 0
    for task_type, valid_index in iterator:
        x, mask, y, y_s, mask_sup= prepare_data([data[0][task][t] for t in valid_index],
                                  numpy.array(data[1][task])[valid_index],task_type, numpy.array(data[2][task])[valid_index],
                                  maxlen=None)
        preds = f_pred_s(x, mask)
        targets = numpy.array(data[2][task])[valid_index]


        valid_err += (preds == targets).sum()
    #print "valid_er:\t%d" %(valid_err)
    #delta = len(data[1][task]) - numpy.array(data[2][task]).sum()
    #print "delta:", delta, "len(data[2])",numpy.array(data[2][task]).sum(), "valid_err",valid_err
    valid_err_rate = 1. - (numpy_floatX(valid_err)) / len(data[0][task])
    res = [valid_err_rate, numpy_floatX(valid_err), len(data[0][task])]
    return res




    '''
    train_data = "q.train",
    test_data = "q.test",
    path_dataset_pkl = "q.pkl",
    '''

def train_lstm(
    train_data = "CR-MR.train.semi",
    test_data = "CR-MR.test.semi",
    path_dataset_pkl = "CR-MR.pkl",
    flag_badcase = 0,
    path_of_emb = "glove.6B.200d.txt.deal",
    flag_initEmb = 1,
    n_samples_examine = 10000,
    w_emb = None,
    V_shared = None,
    eidx = 0,
    G_stop = 100,
    dict_id2task = None,
    dim_proj=200,  # word embeding dimension and LSTM number of hidden units.
    dim_M=20,  # word embeding dimension and LSTM number of hidden units.
    dim_N=50,  # word embeding dimension and LSTM number of hidden units.
    patience=10,  # Number of epoch to wait before early stop if no progress
    max_epochs=100,  # The maximum number of epoch to run
    dispFreq=10,  # Display to stdout the training progress every N updates
    decay_c=0.,  # Weight decay for the classifier applied to the U weights.
    lambda_k = 0.01,
    beta = 0.1,
    lrate=0.001,  # Learning rate for sgd (not used for adadelta and rmsprop)
    n_words=500000,  # Vocabulary size
    optimizer=adadelta,  # sgd, adadelta and rmsprop available, sgd very hard to use, not recommanded (probably need momentum and decaying learning rate).
    encoder='lstm',  # TODO: can be removed must be lstm.
    encoder_task='lstm_task',  # TODO: can be removed must be lstm.
    saveto='lstm_model',  # The best model will be saved there
    loadfrom='lstm_model',  # The best model will be saved there
    validFreq=1000,  # Compute the validation error after this number of update.
    saveFreq=1000,  # Save the parameters after every saveFreq updates
    maxlen=800,  # Sequence longer then this get ignored
    batch_size=8,  # The batch size during training.
    valid_batch_size=8,  # The batch size used for validation/test set.
    dataset='imdb',

    # Parameter for extra option
    noise_std=0.,
    use_dropout=True,  # if False slightly faster, but worst test error
                       # This frequently need a bigger model.
    reload_model= 0,  # Path to a saved model we want to start from.
    test_size=-1,  # If >0, we keep only this number of test example.
):

    # Model options
    model_options = locals().copy()
    print "model options", model_options

    load_data, prepare_data = get_dataset(dataset)

    print 'Loading data'
    #train, valid, test = load_data(train_data = train_data, test_data = test_data, path = path_dataset_pkl ,n_words=n_words, valid_portion=0.05,
                                   #maxlen=maxlen)
    train, valid, test, w_emb, dict_id2task, dict_word, dict_id2word = load_data(reload_model = reload_model, train_data = train_data, test_data = test_data, path = path_dataset_pkl ,path_of_emb = path_of_emb,n_words=n_words, valid_portion=0.05, maxlen=maxlen)
    model_options['w_emb'] = w_emb
    model_options['dict_id2task'] = dict_id2task
    model_options['w_emb'] = w_emb
    model_options['dict_word'] = dict_word
    model_options['dict_id2word'] = dict_id2word
    #model_options['dict_id2label'] = dict_id2label
    num_task = len(train[0])
    #print train[0][0]
    if test_size > 0:
        # The test set is sorted by size, but we want to keep random
        # size example.  So we must select a random selection of the
        # examples.
        #num_task = len(test[0])
        for task in range(num_task):
            idx = numpy.arange(len(test[0][task]))
            numpy.random.shuffle(idx)
            idx = idx[:test_size]
            test[0][task] = [test[0][task][n] for n in idx]
            test[1][task] = [test[1][task][n] for n in idx]
    ydim_list = []
    for task in range(num_task):
        ydim_list.append(numpy.max(train[1][task]) + 1)

    model_options['ydim_list'] = ydim_list
    model_options['num_task'] = num_task

    print 'Building model'
    # This create the initial parameters as numpy ndarrays.
    # Dict name (string) -> numpy ndarray
    params_list, params_shared, params_shared_D, params_D_list  = init_params(model_options,num_task)



    if reload_model:
        params_list, params_shared, params_shared_D, params_D_list = load_params(loadfrom, params_list, params_shared, params_shared_D, params_D_list, num_task)


    # This create Theano Shared Variable from the parameters.
    # Dict name (string) -> Theano Tensor Shared Variable
    # params and tparams have different copy of the weights.
    tparams_list, tparams_shared, tparams_shared_D, tparams_D_list = init_tparams(params_list,params_shared, params_shared_D, params_D_list, num_task)

    # use_noise is for dropout
    use_noise_list=[]
    x_list=[]
    mask_list = []
    y_list = []
    y_s_list = []
    f_pred_prob_list = []
    f_pred_list = []
    f_pred_s_list = []
    cost_list = []
    cost_s_list = []
    f_cost_list = []
    f_cost_s_list = []
    grads_list = []
    grads_s_list = []
    f_grad_list = []
    f_grad_s_list = []
    f_grad_shared_list = []
    f_grad_shared_list_s = []
    f_update_list = []
    mask_sup_list = []
    f_info_list = []
    cost_diff_list = []
    f_cost_diff_list = []
    grads_diff_list = []
    f_grad_diff_list = []
    for task in range(num_task):
        #(use_noise, x, mask, y, f_pred_prob, f_pred, cost) = build_model(tparams, model_options)
        res = build_model(tparams_list[task], tparams_shared, tparams_shared_D, tparams_D_list[task],model_options)
        use_noise_list.append(res[0])
        x_list.append(res[1])
        mask_list.append(res[2])
        y_list.append(res[3])
        f_pred_prob_list.append(res[4])
        f_pred_list.append(res[5])
        cost_list.append(res[6])
        y_s_list.append(res[7])
        cost_s_list.append(res[8])
        mask_sup_list.append(res[9])
        f_pred_s_list.append(res[10])
        f_info_list.append(res[11])
        cost_diff_list.append(res[12])
        

        if decay_c > 0.:
            decay_c = theano.shared(numpy_floatX(decay_c), name='decay_c')
            weight_decay = 0.
            weight_decay += (tparams_list[task]['U'] ** 2).sum()
            weight_decay *= decay_c
            cost_list[task] += weight_decay
        
        # Compute gradient  
        # Parameters: shared variable with shared D
        # Loss: GAN
        f_cost_s_list.append(theano.function([x_list[task], mask_list[task], y_s_list[task]], cost_s_list[task], name='f_cost_s'+str(task)))
        grads_s_list.append(tensor.grad(cost_s_list[task], wrt = tparams_shared.values() + tparams_shared_D.values()))
        f_grad_s_list.append(theano.function([x_list[task], mask_list[task], y_s_list[task]], grads_s_list[task], name='f_grad_s'+str(task)))
        
        f_cost_diff_list.append(theano.function([x_list[task], mask_list[task]], cost_diff_list[task], name='f_cost_diff'+str(task)))
        grads_diff_list.append(tensor.grad(cost_diff_list[task], wrt =tparams_list[task].values() + tparams_shared.values() ))
        f_grad_diff_list.append(theano.function([x_list[task], mask_list[task]], grads_diff_list[task], name='f_grad_diff'+str(task)))
        # Compute gradient  
        # Parameters: task-specific and shared variable without shared_D
        # Loss: supervised loss
        f_cost_list.append(theano.function([x_list[task], mask_list[task], y_list[task], mask_sup_list[task]], cost_list[task], name='f_cost'+str(task)))
        grads_list.append(tensor.grad(cost_list[task], wrt=tparams_list[task].values() + tparams_D_list[task].values() + tparams_shared.values() ))
        f_grad_list.append(theano.function([x_list[task], mask_list[task], y_list[task], mask_sup_list[task]], grads_list[task], name='f_grad'+str(task)))

        lr = tensor.scalar(name='lr')
        f_grad_shared, f_update, f_grad_shared_s = optimizer(model_options, lr, tparams_list[task], tparams_shared, tparams_shared_D, tparams_D_list[task], grads_list[task],x_list[task], mask_list[task], y_list[task], y_s_list[task], cost_list[task], grads_s_list[task],cost_s_list[task], mask_sup_list[task],grads_diff_list[task],cost_diff_list[task])
        f_grad_shared_list.append(f_grad_shared)
        f_update_list.append(f_update)
        f_grad_shared_list_s.append(f_grad_shared_s)

    print 'Optimization'






    kf_valid_list=[]
    kf_test_list=[]
    for task in range(num_task):
        kf_valid_list.append(get_minibatches_idx(len(valid[0][task]), valid_batch_size,task))
        kf_test_list.append(get_minibatches_idx(len(test[0][task]), valid_batch_size,task))
        #print kf_test_list[task]



    #kf_valid = get_minibatches_idx(len(valid[0]), valid_batch_size)
    #kf_test = get_minibatches_idx(len(test[0]), valid_batch_size)

    for task in range(num_task):
        print "task:%s\t" %(dict_id2task[task])
        print "%d train examples" % len(train[0][task])
        print "%d valid examples" % len(valid[0][task])
        print "%d test examples" % len(test[0][task])

    history_errs = []
    best_p_list = None
    bad_count = 0



    if reload_model:
        for task in range(num_task):
            print "--------Reload... Task:%s--------" %(dict_id2task[task])
            use_noise_list[task].set_value(0.)
            test_err  = pred_error(f_pred_list[task], prepare_data, test,  kf_test_list[task],  task)
            print test_err
            #test_err = pred_error_detail(model_options, f_pred_list[task], f_info_list[task], prepare_data, test, kf_test_list[task], task)
        
        exit()




    '''
    if validFreq == -1:
        validFreq = len(train[0][0]) / batch_size
    if saveFreq == -1:
        saveFreq = len(train[0][0]) / batch_size
    '''
    uidx = 0  # the number of update done
    estop = False  # early stop
    start_time = time.time()
    try:
        for eidx in xrange(max_epochs):
            n_samples = 0
            model_options['eidx'] = eidx
            # Get new shuffled index for the training set.
            #kf = get_minibatches_idx(len(train[0]), batch_size, shuffle=True)
            kf_train_list = []
            kf = []
            for task in range(num_task):
                kf_train_list.append(get_minibatches_idx(len(train[0][task]), batch_size, task, shuffle=True))
                kf += kf_train_list[task]
            idx = numpy.arange(len(kf))
            numpy.random.shuffle(idx)
            kf = [kf[i] for i in idx]

            for task_type, train_index in kf:
                uidx += 1
                use_noise_list[task_type].set_value(1.)

                # Select the random examples for this minibatch
                z = [train[2][task_type][t] for t in train_index]
                y = [train[1][task_type][t] for t in train_index]
                x = [train[0][task_type][t]for t in train_index]

                # Get the data in numpy.ndarray format
                # This swap the axis!
                # Return something of shape (minibatch maxlen, n samples)
                x, mask, y, y_s, mask_sup = prepare_data(x, y,task_type,z)
                n_samples += x.shape[1]

                cost = f_grad_shared_list[task_type](x, mask, y, y_s,mask_sup)
                cost_s = f_grad_shared_list_s[task_type](x, mask, y_s)
                cost_diff = f_info_list[task_type](x,mask)[-1]
                f_update_list[task_type](lrate)

                if reload_model and eidx ==0 and uidx == 1:
                    for task in range(num_task):
                        print "--------Reload... Task:%s--------" %(dict_id2task[task])
                        use_noise_list[task].set_value(0.)

                        
                        #info = f_info(x,mask)
                        train_err = pred_error(f_pred_list[task], prepare_data, train, kf_train_list[task], task)
                        valid_err = pred_error(f_pred_list[task], prepare_data, valid, kf_valid_list[task], task)
                        #test_err = pred_error_detail(model_options, f_pred_list[task], f_info, prepare_data, test, kf_test_list[task], task)
                        test_err  = pred_error(f_pred_list[task], prepare_data, test,  kf_test_list[task],  task)

                        train_err_s = pred_error_s(f_pred_s_list[task], prepare_data, train, kf_train_list[task], task)
                        valid_err_s = pred_error_s(f_pred_s_list[task], prepare_data, valid, kf_valid_list[task], task)
                        test_err_s  = pred_error_s(f_pred_s_list[task], prepare_data, test,  kf_test_list[task],  task)

                        print "supervised learning: ", train_err, valid_err, test_err
                        print "task types prediction: ", train_err_s, valid_err_s, test_err_s

                if numpy.isnan(cost) or numpy.isinf(cost):
                    print 'bad cost detected: ', cost
                    return 1., 1., 1.

                if numpy.mod(uidx, dispFreq) == 0:
                    print 'Epoch ', eidx, 'Update ', uidx, 'Cost_sup ', cost, 'Gan', cost_s,'Cost_diff', cost_diff/model_options['beta']

                if saveto and numpy.mod(uidx, saveFreq) == 0:
                    print 'Saving...',
                    
                    if best_p_list is not None:
                        for task in range(num_task):
                            params_list[task] = best_p_list[2*task] 
                            params_D_list[task] = best_p_list[2*task+1] 
                        params_shared = best_p_list[2*num_task]
                        params_shared_D = best_p_list[2*num_task+1]

                    else:
                        for task in range(num_task):
                            params_list[task] = unzip(tparams_list[task])
                            params_D_list[task] = unzip(tparams_D_list[task])
                        params_shared = unzip(tparams_shared)
                        params_shared_D = unzip(tparams_shared_D)
                    
                    for task in range(num_task):
                        new_saveto = saveto + "_" + str(2*task) + ".npz"
                        numpy.savez(new_saveto, history_errs=history_errs, **params_list[task])
                        new_saveto = saveto + "_" + str(2*task+1) + ".npz"
                        numpy.savez(new_saveto, history_errs=history_errs, **params_D_list[task])
                    new_saveto = saveto + "_" + str(2*num_task) + ".npz"
                    numpy.savez(new_saveto, **params_shared)
                    new_saveto = saveto + "_" + str(2*num_task+1) + ".npz"
                    numpy.savez(new_saveto, **params_shared_D)
                    pkl.dump(model_options, open('%s.pkl' % saveto, 'wb'), -1)
                    print 'Done'


                    '''
                    if uidx>500:
                        params_list, params_shared, params_shared_D = load_params(loadfrom, params_list, params_shared, params_shared_D, num_task)
                        tparams_list, tparams_shared, tparams_shared_D =       init_tparams(params_list, params_shared, params_shared_D, num_task)
                        for task in range(num_task):
                            print "--------Reload... Task:%s--------" %(dict_id2task[task])
                            use_noise_list[task].set_value(0.)
                            test_err  = pred_error(f_pred_list[task], prepare_data, test,  kf_test_list[task],  task)
                            #test_err = pred_error_detail(model_options, f_pred_list[task], f_info_list[task], prepare_data, test, kf_test_list[task], task)
                            print test_err
                        
                        exit()
                    '''

                if numpy.mod(uidx, saveFreq) == 0:
                    use_noise_list[task_type].set_value(0.)
                    for task in range(num_task):
                        if dict_id2task[task] == "MR":
                            test_err = pred_error_detail(model_options, f_pred_list[task], f_info_list[task], prepare_data, test, kf_test_list[task], task)
                            print test_err

                            
                if numpy.mod(uidx, validFreq) == 0:
                    use_noise_list[task_type].set_value(0.)
                    #train_err = pred_error(f_pred, prepare_data, train, kf)
                    valid_err_sum = 0
                    test_err_sum = 0
                    print ""
                    sum_wrong = 0
                    sum_samples = 0
                    for task in range(num_task):
                        print "--------Task:%s--------" %(dict_id2task[task])
                        train_err = pred_error(f_pred_list[task], prepare_data, train, kf_train_list[task], task)
                        valid_err = pred_error(f_pred_list[task], prepare_data, valid, kf_valid_list[task], task)
                        test_err  = pred_error(f_pred_list[task], prepare_data, test,  kf_test_list[task],  task)
                        #test_err = pred_error_detail(model_options, f_pred_list[task], f_info_list[task], prepare_data, test, kf_test_list[task], task)

                        train_res = pred_error_s(f_pred_s_list[task], prepare_data, train, kf_train_list[task], task)
                        valid_res = pred_error_s(f_pred_s_list[task], prepare_data, valid, kf_valid_list[task], task)
                        test_res  = pred_error_s(f_pred_s_list[task], prepare_data, test,  kf_test_list[task],  task)
                        print "supervised learning: ", train_err, valid_err, test_err
                        sum_wrong += test_res[1]
                        sum_samples += test_res[2]
                        valid_err_sum += valid_err
                        test_err_sum += test_err
                    print "all the task test errors: ", test_err_sum
                    history_errs.append([valid_err_sum, test_err_sum])

                    if (best_p_list is None or
                        valid_err_sum <= numpy.array(history_errs)[:,
                                                               0].min()):

                        best_p_list=[]
                        for task in range(num_task):
                            best_p_list.append(unzip(tparams_list[task]))
                            best_p_list.append(unzip(tparams_D_list[task]))
                        best_p_list.append(unzip(tparams_shared))
                        best_p_list.append(unzip(tparams_shared_D))

                        bad_counter = 0

                    #print ('Train ', train_err, 'Valid ', valid_err,
                    #       'Test ', test_err)

                    if (len(history_errs) > patience and
                        valid_err_sum >= numpy.array(history_errs)[:-patience,
                                                               0].min()):
                        bad_counter += 1
                        if bad_counter > patience:
                            print 'Early Stop!'
                            estop = True
                            break

            print 'Seen %d samples' % n_samples

            if estop:
                break

    except KeyboardInterrupt:
        print "Training interupted"

    end_time = time.time()
    if best_p_list is not None:
        for task in range(num_task):
            zipp(best_p_list[2*task], tparams_list[task])
            zipp(best_p_list[2*task+1], tparams_D_list[task])
        zipp(best_p_list[2*num_task], tparams_shared)
        zipp(best_p_list[2*num_task+1], tparams_shared_D)

    else:
        best_p_list=[]
        for task in range(num_task):
            best_p_list.append(unzip(tparams_list[task]))
            best_p_list.append(unzip(tparams_D_list[task]))
        best_p_list.append(unzip(tparams_shared))
        best_p_list.append(unzip(tparams_shared_D))

    #use_noise.set_value(0.)
    train_err = 0
    valid_err = 0
    test_err = 0
    for task in range(num_task):
        print "--------Task:%s--------" %(dict_id2task[task])
        use_noise_list[task].set_value(0.)
        train_err = pred_error(f_pred_list[task], prepare_data, train, kf_train_list[task], task)
        valid_err = pred_error(f_pred_list[task], prepare_data, valid, kf_valid_list[task], task)
        test_err  = pred_error(f_pred_list[task], prepare_data, test,  kf_test_list[task],  task)
        print 'Train ', train_err, 'Valid ', valid_err, 'Test ', test_err
    #kf_train_sorted = get_minibatches_idx(len(train[0]), batch_size)
    #train_err = pred_error(f_pred, prepare_data, train, kf_train_sorted)
    #valid_err = pred_error(f_pred, prepare_data, valid, kf_valid)
    #test_err = pred_error(f_pred, prepare_data, test, kf_test)



    if saveto:
        for task in range(2*num_task+2):
            new_saveto = saveto + "_" + str(task) + ".npz"
            numpy.savez(new_saveto, train_err=train_err, valid_err=valid_err, test_err=test_err, **best_p_list[task])
        #new_saveto = saveto + "_shared.npz"
        #numpy.savez(new_saveto, **params_shared)
        '''
        numpy.savez(saveto, train_err=train_err,
                    valid_err=valid_err, test_err=test_err,
                    history_errs=history_errs, **best_p_list[0])
        '''
    print 'The code run for %d epochs, with %f sec/epochs' % (
        (eidx + 1), (end_time - start_time) / (1. * (eidx + 1)))
    print >> sys.stderr, ('Training took %.1fs' %
                          (end_time - start_time))

    return train_err, valid_err, test_err


if __name__ == '__main__':
    # See function train for all possible parameter and there definition.
    train_lstm(
        max_epochs=200,
        test_size=25000,
    )
