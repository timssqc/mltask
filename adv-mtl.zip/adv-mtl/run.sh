rm -fr imdb.pyc
export THEANO_FLAGS=device=gpu1,floatX=float32
python mtl-lstm.py
